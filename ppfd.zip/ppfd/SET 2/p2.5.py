import pandas as pd
file_name = input("Enter the Excel file name (with .xlsx or .xls extension): ")
try:
    data = pd.read_excel(file_name, engine='openpyxl')
    print("\nData in the Excel file:")
    print(data.to_markdown(index=False))
except FileNotFoundError:
    print(f"File '{file_name}' was not found. Please check the file path.")
except PermissionError:
    print(f"Error: permission denied. Close the file if it's open in another application and try again.")
except ValueError as e:
    print(f"Error: {e}. Please ensure the file is a valid Excel file.")
except Exception as e:
    print(f"An unexpected error occurred: {e}")
class Student:
    def __init__(self, name, student_id):
        self.name = name
        self.student_id = student_id
        self.grades = {}

    def assign_grade(self, course_name, grade):
        self.grades[course_name] = grade

class Teacher:
    def __init__(self, name, subject):
        self.name = name
        self.subject = subject

class Course:
    def __init__(self, course_name, teacher):
        self.course_name = course_name
        self.teacher = teacher
        self.enrolled_students = []

    def enroll_student(self, student):
        self.enrolled_students.append(student)
        print(f"Enrolled {student.name} in {self.course_name}")

# --- Usage (Creating Instances) ---
mr_jones = Teacher("Mr. Jones", "Computer Science")
python_101 = Course("Intro to Python", mr_jones) 

alice = Student("Alice", "S101")
python_101.enroll_student(alice)

print(f"Course: {python_101.course_name} | Teacher: {python_101.teacher.name}")
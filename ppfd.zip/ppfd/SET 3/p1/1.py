from http.server import HTTPServer, SimpleHTTPRequestHandler

HOST = "localhost"
PORT = 8000


class StaticWebServer(SimpleHTTPRequestHandler):
    def do_GET(self):
        # Serve index.html when root URL is accessed
        if self.path == "/":
            self.path = "/index.html"
        return super().do_GET()


def start_server():
    server_address = (HOST, PORT)
    httpd = HTTPServer(server_address, StaticWebServer)
    print(f"Server running at http://{HOST}:{PORT}")
    httpd.serve_forever()


if __name__ == "__main__":
    start_server()

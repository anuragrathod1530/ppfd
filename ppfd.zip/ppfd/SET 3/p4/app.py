from flask import Flask, render_template
import sqlite3

app = Flask(__name__)
DATABASE = "employees.db"

# Initialize database
def init_db():
    with sqlite3.connect(DATABASE) as conn:
        cursor = conn.cursor()
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS employees (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT,
            department TEXT,
            salary INTEGER
        )
        """)

        cursor.execute("SELECT COUNT(*) FROM employees")
        if cursor.fetchone()[0] == 0:
            cursor.executemany(
                "INSERT INTO employees (name, department, salary) VALUES (?, ?, ?)",
                [
                    ("Alice", "HR", 50000),
                    ("Bob", "IT", 60000),
                    ("Charlie", "Finance", 70000)
                ]
            )
        conn.commit()

# Display data
@app.route("/")
def index():
    with sqlite3.connect(DATABASE) as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM employees")
        data = cursor.fetchall()

    return render_template("table.html", employees=data)

if __name__ == "__main__":
    init_db()
    app.run(debug=True)

numbers = input("ENTER NUMBERS SEPERATED BY SPACE: ").split()
numbers = [int(num) for num in numbers]
total = sum(numbers)
count = len(numbers)
average = total / count
print("AVERAGE IS:",average)

number = input("Enter the number: ")
from_base = int(input("Enter the base of the number: "))
to_base = int(input("Enter the base to convert into: "))

decimal = int(number, from_base)

result = ""
digits = "0123456789ABCDEF"

while decimal > 0:
    result = digits[decimal % to_base] + result
    decimal //= to_base

print("Converted number:", result)                                                                                                                                                                                                            
numbers = [5, 2, 9, 1, 3]
numbers.sort()
print(numbers)
numbers = [5, 2, 9, 1, 3]
numbers.sort(reverse=True)
print(numbers)
print("Sorted in ascending and descending order respectively.")
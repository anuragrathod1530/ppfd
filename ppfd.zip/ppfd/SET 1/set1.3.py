import random
import string
l=int(input("ENTER LENGTH OF YOUR PASSWORD: "))
characters = string.ascii_letters + string.digits + string.punctuation
password = ''.join(random.choice(characters) for i in range(l))
print("YOUR GENERATED PASSWORD IS: ",password)
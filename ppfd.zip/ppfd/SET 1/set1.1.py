celsius = int(input("Enter temperature in Celsius: "))
fahrenheit = (celsius * 1.8) + 32
print(celsius, "celsius is equal to", fahrenheit, "fahrenheit")

fahrenheit2 = int(input("Enter temperature in Fahrenheit: "))
celsius2 = (fahrenheit2 - 32) * 5/9
print(fahrenheit2, "fahrenheit is equal to", celsius2, "celsius")

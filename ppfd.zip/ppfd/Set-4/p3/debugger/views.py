from django.http import HttpResponse
import logging

logger = logging.getLogger(__name__)

def home(request):
    logger.debug("Home page accessed")
    return HttpResponse("Django Debugging Demo Running")


def error_test(request):
    logger.debug("Error endpoint triggered")

    # Intentional error for debugging
    x = 10
    y = 0

    result = x / y

    return HttpResponse(result)
from django.urls import path
from . import views

urlpatterns = [
    path('', views.home),
    path('error/', views.error_test),
]